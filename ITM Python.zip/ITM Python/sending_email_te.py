import smtplib
FROM = ""
PASSWORD = ""
TO =["","","",""]
MSG = """
subject : something


body""" 

con = smtplib.SMTP("smtp.gmail.com",587)

con.ehlo()

con.starttls()

con.login(FROM,PASSWORD)

for i in TO:
    con.sendmail(FROM,i,MSG)

con.close()
