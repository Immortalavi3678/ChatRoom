class Duster:
    brand = "something"


obj1 = Duster()

print(obj1)