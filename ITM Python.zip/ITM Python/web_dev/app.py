from flask import Flask,render_template
app = Flask("app")

@app.route("/")
def show():
    return render_template("index.html")

@app.route("/next")
def show2():
    return render_template("next.html")

if __name__ == "__main__":
    app.run()
