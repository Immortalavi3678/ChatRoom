import socket
import tkinter as tk
import threading as th

host = "192.168.197.66"
port = 12347
server_add = (host,port)

data = ""

def ser_socket():
    global data,root
    with socket.socket(socket.AF_INET,socket.SOCK_STREAM) as ser:
        print("Creating the server socket")
        ser.bind((host,port))
        print("server socket started")
        
        print("waiting for client")
        ser.listen()

        c,r = ser.accept()
        print("connecting with client")
        print(r)
        print("starting conversation.......")
        while True:
            data = c.recv(1024)
            data = data.decode()
            l1 = tk.Label(root,text="heading",bg="purple",fg="white",)
            l1.pack()
            l1.config(text = data)
            l1.update_idletasks()
            print("cli: ",data)



root = tk.Tk()
t1 = th.Thread(target=ser_socket)
t1.start()
root.mainloop()







